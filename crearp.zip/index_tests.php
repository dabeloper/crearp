<?php
	@session_start();
?>
<!DOCTYPE html>
<html lang="es-CO">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

  <title> Prueba Tecnica - Crear Publicitarios</title>

  <link rel="shortcut icon" href="./src/resources/logo.png">

  <meta name="description" content="Solucion Prueba Técnica para Crear Publicitarios ltda. Por David Antonio Bolaños Lamprea AKA DABELOPER">
  <link rel="stylesheet" href="./src/resources/all.css" type="text/css" media="all">
  <link rel="stylesheet" href="./src/resources/library.css" type="text/css" media="all">
</head>

<body class="single single-post postid-67 single-format-standard">

<nav>

  <section>

    <a href="#" class="brand">
     <img src="./src/resources/logo.png" width="50"/>
    </a>
    <div id="mobile-nav-toggle">
      <a href="#" id="nav-toggle" data-nav-toggle="">
        <span class="hamburger"></span>
      </a>
    </div>
    <a class="fixed-cta" href="#">Prueba Tecnica - Crear Publicitarios</a>

    <ul id="guest-nav" class="nav-list">
      <li class="nav-item ">
        <a href="#login" onClick="showSection('login')" class="nav-anchor">Ingresar</a>
      </li>
      <li class="nav-item nav-item-more">
        <a href="#sign_up" onClick="showSection('sign_up')" class="nav-anchor">Registrarse</a>
      </li>
    </ul>

    <ul id="user-nav" class="nav-list hide">
      <li class="nav-item ">
        <a href="#courses" class="nav-anchor">Electivas</a>
      </li>
      <li class="nav-item ">
        <a href="#account" class="nav-anchor">Mi Cuenta</a>
      </li>
      <li class="nav-item nav-item-more">
        <a href="#logout" onClick="submit_logout()" class="nav-anchor">Salir</a>
      </li>
    </ul>

    <ul id="admin-nav" class="nav-list hide">
      <li class="nav-item">
        <a href="#admin" class="nav-anchor">Administrar</a>
      </li>
      <li class="nav-item nav-item-more">
        <a href="#logout" onClick="submit_logout()" class="nav-anchor">Salir</a>
      </li>
    </ul>

  </section>
</nav>

  <div class="page-container">

	<div id="snackbar"></div>

  <section class="hero has-tag-icon tag-php">
    <h1 id="post-title" >
      Prueba Tecnica
    </h1>
  </section>



  <!-- Seccion para "Ingresar" -->
	<section id="login" class="page-content">

	  <div class="row">

	    <div class="skinny-read">
	      <div class="meta"><em>Ingresar</em></p>
	    </div>

		<div>
		  <p>
		  	<label for="user_id_login"><small style="opacity: 1;">Identificación o Cedula<em>*</em></small></label>
		  	<input type="text" name="user_id_login" id="user_id_login" value="" size="11" tabindex="1" aria-required="true" required>
		  </p>

		  <p style="display: inline-block;">
		  	<input type="button" style="width: 100%;" class="button primary" onClick="submit_login()" value="Ingresar">
		  </p>
		</div>

	    </div>
	  </div>
	</section>
  <!-- FIN :: Seccion para "Ingresar" -->



  <!-- Seccion para "Registro" -->
	<section id="sign_up" class="page-content">

	  <div class="row">

	    <div class="skinny-read">
	       <div class="meta">
          <em>Registro</em></p>
	       </div>

  		<div>

  		  <p>
  		  	<label for="user_id_signup"><small style="opacity: 1;">Identificación o Cedula<em>*</em></small></label>
  		  	<input type="text" name="user_id_signup" id="user_id_signup" value="" size="11" tabindex="1" aria-required="true" required>
  		  </p>

  		  <p>
  		  	<label for="user_name"><small style="opacity: 1;">Nombre<em>*</em></small></label>
  		  	<input type="text" name="user_name" id="user_name" value="" size="255" tabindex="1" aria-required="true" required>
  		  </p>

  		  <p>
  		  	<label for="is_admin"><small style="opacity: 1;">Tipo de Usuario<em>*</em></small></label>
  		  	<select id="is_admin" name="is_admin" required>
  		      <option value="false">Estudiante</option>
  		      <option value="false">Profesor</option>
  		      <option value="true">Administrador</option>
  		    </select>

  		  </p>

  		  <p style="display: inline-block;">
  		  	<input type="button" style="width: 100%;" class="button primary" onClick="submit_sign_up()" value="Registrarse">
  		  </p>
  		</div>

	    </div>
	  </div>
	</section>
  <!-- FIN :: Seccion para "Registro" -->


  <!-- Seccion para "Listar Resultados" -->
	<section id="user-courses" class="page-content">
    <div class="row">
    <div class="contained control-container search" ><!-- add class search-focused -->
    <!-- Search -->
    <div class="search-container">
      <form class="control-search search-form">
        <label for="search">
          <svg preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18" class="loading-icon">
            <path class="loading-circle" d="M9,4c2.76,0,5,2.24,5,5s-2.24,5-5,5s-5-2.24-5-5S6.24,4,9,4 M9,0C4.03,0,0,4.03,0,9s4.03,9,9,9s9-4.03,9-9S13.97,0,9,0L9,0z"></path>
            <path class="loading-quarter-circle" d="M16,11c-1.1,0-2-0.9-2-2c0-2.76-2.24-5-5-5C7.9,4,7,3.1,7,2s0.9-2,2-2c4.96,0,9,4.04,9,9C18,10.1,17.1,11,16,11z"></path>
          </svg>

          <svg preserveAspectRatio="xMinYMin meet" viewBox="0 0 16 16" class="search-icon">
            <path d="M15.6,13.5l-4-4c0.6-1,1-2.1,1-3.3C12.5,2.8,9.8,0,6.3,0C2.9,0,0,2.8,0,6.2c0,3.4,2.8,6.2,6.3,6.2
            c1.2,0,2.2-0.3,3.1-0.9l4,4.1c0.5,0.5,1.5,0.5,2.1,0C16.1,15,16.1,14.1,15.6,13.5z M6.5,9.4c-1.8,0-3.3-1.5-3.3-3.2
            C3.2,4.4,4.7,3,6.5,3s3.3,1.5,3.3,3.2C9.7,8,8.3,9.4,6.5,9.4z"></path>
          </svg>
        </label>

        <div class="search-input">
            <input type="text" class="search input-text" id="q" placeholder="Buscar Usuarios y Electivas...">
        </div>
      </form>
    </div>

    <!-- Control Page Items -->
    <ul class="control-page-items">

        <!-- Filtering -->
        <li class="static-option">
          <a class="static-option-label" onClick="find_courses()" >Buscar Usuario</a>
        </li>

        <!-- Courses -->
        <li class="static-option">
          <a class="static-option-label" onClick="find_courses()" >Buscar Electiva</a>
        </li>


    </ul>
    </div>
    <a class="button button-blue" onClick="user_get_all_courses()" >Mostrar todas las Electivas</a>
    <a class="button button-blue" onClick="user_get_my_courses()" >Mis Inscripciones</a>


	</section>
  <!-- FIN :: Seccion para "Listar Resultados" -->

  <div class="row" id="results">
      <ul></ul>
  </div>

  <!-- Seccion para "Administrar Cursos (Administradir)" -->
	<section id="admin-courses" class="page-content">

	  <div class="row">
      <ul></ul>
	  </div>
	</section>
  <!-- FIN :: Seccion para "Administrar Cursos (Usuario)" -->








<!-- EJEMPLO DE TARJETAS :: ELIMINAR ANTES DE SUBIR -->
<ul class="">

      <li class="card course syllabus topic-data-analysis">

      <a class="card-box" href="/library/introduction-to-big-data">
        <div class="card-progress">
          <svg class="course-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18">
            <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#course-icon"></use>
          </svg>

          <ul class="card-stages">
              <li>1</li>
              <li>2</li>
              <li>3</li>
          </ul>

          <span class="card-estimate">51 min</span>
        </div>

        <strong class="card-type">Course</strong>
        <h3 class="card-title">Introduction to Big Data</h3>
        <p class="card-description">
          Big data represents an entire ecosystem of data sets, tools, and applications.  This course is intended to get you familiar with the concepts, problem spaces, and overall ecosystem of Big Data.
        </p>


          <div class="card-status">
            <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
            <span class="card-status-title"></span>
          </div>
      </a>

      <ul class="card-tags tags">
        <li class="pro-content"><a href=""><span>Pro</span></a></li>
        <li class="topic-data-analysis topic topic"><a data-filter-list-val="topic:data-analysis" href="/library/topic:data-analysis"><span>Data Analysis</span></a></li>
        <li class="difficulty"><span>Intermediate</span></li>
        <li class="truncated-tags"><span></span><ul></ul></li>
      </ul>
    </li>


<li class="card course syllabus topic-design" data-location="library" data-activity="syllabus/92" id="Syllabus-92">

  <a class="card-box" href="/library/mobile-app-design-for-ios">
    <div class="card-progress">
      <svg class="course-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#course-icon"></use></svg>

      <ul class="card-stages">
          <li>1</li>
          <li>2</li>
          <li>3</li>
          <li>4</li>
          <li>5</li>
      </ul>

      <span class="card-estimate">2 hours</span>
    </div>

    <strong class="card-type">Course</strong>
    <h3 class="card-title">Mobile App Design for iOS</h3>
    <p class="card-description">
      Learn the basics of designing a mobile app, from initial idea, wireframes to user interface design. You will create the design for a diary app while learning how to write an application design specification, user experience, right through to creating assets for development. The project will focus on the iOS platform, however you learn some tips and tricks on adapting the design for platforms like Android and Windows.
    </p>


      <div class="card-status">
        <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
        <span class="card-status-title"></span>
      </div>
</a>
  <ul class="card-tags tags">
    <li class="topic-design topic topic"><a data-filter-list-val="topic:design" href="/library/topic:design"><span>Design</span></a></li><li class="difficulty"><span>Beginner</span></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>
</li>



<li class="card course syllabus topic-css" data-location="library" data-activity="syllabus/78" id="Syllabus-78">

  <a class="card-box" href="/library/framework-basics">
    <div class="card-progress">
      <svg class="course-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#course-icon"></use></svg>

      <ul class="card-stages">
          <li>1</li>
          <li>2</li>
          <li>3</li>
          <li>4</li>
          <li>5</li>
          <li>6</li>
      </ul>

      <span class="card-estimate">7 hours</span>
    </div>

    <strong class="card-type">Course</strong>
    <h3 class="card-title">Framework Basics</h3>
    <p class="card-description">
      Sometimes the hardest part about building a website is knowing where or how to start. In this course, we'll learn how to build a website using two of the most widely used Frameworks in the industry: Bootstrap and Foundation. First, we'll build a prototype using each framework's common CSS features, components, and JavaScript plugins. We'll then put everything we've learned about Bootstrap and Foundation into practice by building a simple marketing website for Ribbit, the self-destructing message app for iOS and Android.
    </p>


      <div class="card-status">
        <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
        <span class="card-status-title"></span>
      </div>
</a>
  <ul class="card-tags tags">
    <li class="topic-css topic topic"><a data-filter-list-val="topic:css" href="/library/topic:css"><span>CSS</span></a></li><li class="difficulty"><span>Beginner</span></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>
</li>





<li class="card bonus-content-series topic-undefined" data-location="library" data-activity="bonus_content_series/17" id="BonusContentSeries-17">

  <a class="card-box" href="/library/treehouse-quick-tips">
    <div class="card-progress">
      <svg class="bonus-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#bonus-icon"></use></svg>
      <span class="card-estimate add-topic-background-color">3 hours</span>
    </div>
    <strong class="card-type">Bonus Series</strong>
    <h3 class="card-title">Treehouse Quick Tips</h3>
    <p class="card-description">Treehouse Quick Tips are fast and easy lessons that you can start applying now.
Learn to create stunning designs in Photoshop, beautiful websites, and useful mobile apps for Android and iOS.</p>
    <div class="card-status">
      <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
      <span class="card-status-title">Viewed</span>
    </div>
</a>
  <ul class="card-tags tags">
    <li class="pro-content"><a href="/account/enrollment"><span>Pro</span></a></li>
    <li class="topics"><span>9 topics</span><ul><li class="topic-html topic topic-html"><a data-filter-list-val="topic:html" href="/library/topic:html"><span>HTML</span></a></li><li class="topic-css topic topic-css"><a data-filter-list-val="topic:css" href="/library/topic:css"><span>CSS</span></a></li><li class="topic-design topic topic-design"><a data-filter-list-val="topic:design" href="/library/topic:design"><span>Design</span></a></li><li class="topic-javascript topic topic-javascript"><a data-filter-list-val="topic:javascript" href="/library/topic:javascript"><span>JavaScript</span></a></li><li class="topic-ruby topic topic-ruby"><a data-filter-list-val="topic:ruby" href="/library/topic:ruby"><span>Ruby</span></a></li><li class="topic-php topic topic-php"><a data-filter-list-val="topic:php" href="/library/topic:php"><span>PHP</span></a></li><li class="topic-ios topic topic-ios"><a data-filter-list-val="topic:ios" href="/library/topic:ios"><span>iOS</span></a></li><li class="topic-android topic topic-android"><a data-filter-list-val="topic:android" href="/library/topic:android"><span>Android</span></a></li><li class="topic-business topic topic-business"><a data-filter-list-val="topic:business" href="/library/topic:business"><span>Business</span></a></li></ul></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>


</li>



<li class="card workshop topic-android " data-location="library" data-activity="workshop/1602" id="Workshop-1602">

  <a class="card-box" href="/library/rxjava">
    <div class="card-progress">
      <svg class="workshop-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#workshop-icon"></use></svg>
      <span class="card-estimate add-topic-background-color">65 min</span>
    </div>
    <strong class="card-type">Workshop</strong>
    <h3 class="card-title">RxJava</h3>
    <p class="card-description">Heard of RxJava but not sure what it is? Want to jump in but don’t know where to start? Join Jamie Huson in this workshop where you build an app using the popular RxJava framework. You’ll learn concepts and implementation to get you started using this technology in your app today!</p>
    <div class="card-status">
      <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
      <span class="card-status-title">Viewed</span>
    </div>
</a>
  <ul class="card-tags tags">
    <li class="pro-content"><a href="/account/enrollment"><span>Pro</span></a></li><li class="topic-android topic topic"><a data-filter-list-val="topic:android" href="/library/topic:android"><span>Android</span></a></li><li class="difficulty"><span>Advanced</span></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>


</li>



<li class="card course syllabus topic-javascript" data-location="library" data-activity="syllabus/2512" id="Syllabus-2512">

  <a class="card-box" href="/library/build-a-rest-api-with-express">
    <div class="card-progress">
      <svg class="course-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#course-icon"></use></svg>

      <ul class="card-stages">
          <li>1</li>
          <li>2</li>
          <li>3</li>
          <li>4</li>
          <li>5</li>
      </ul>

      <span class="card-estimate">3 hours</span>
    </div>

    <strong class="card-type">Course</strong>
    <h3 class="card-title">Build a REST API With Express</h3>
    <p class="card-description">
      REST services are a powerful way of providing functionality over the internet. Not only can they be used as a foundation to build sophisticated web applications, they can also be integrated into any number of other projects, making them the ultimate in modularity and reusability! Instead of having to rebuild an application for several platforms, for example -- iOS, Android, browser, etc -- you can build the back-end once and just add user interfaces as needed. You can build a REST service in many different languages/platforms, but for this course, we will be building one with Express, a popular framework written for Node.js. We will also use Mongoose with MongoDB to persist our data. Let’s get started!
    </p>


      <div class="card-status">
        <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
        <span class="card-status-title"></span>
      </div>
</a>
  <ul class="card-tags tags">
    <li class="topic-javascript topic topic"><a data-filter-list-val="topic:javascript" href="/library/topic:javascript"><span>JavaScript</span></a></li><li class="difficulty"><span>Intermediate</span></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>
</li>



<li class="card workshop topic-business " data-location="library" data-activity="workshop/472" id="Workshop-472">

  <a class="card-box" href="/library/how-to-use-google-analytics">
    <div class="card-progress">
      <svg class="workshop-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#workshop-icon"></use></svg>
      <span class="card-estimate add-topic-background-color">55 min</span>
    </div>
    <strong class="card-type">Workshop</strong>
    <h3 class="card-title">How to Use Google Analytics</h3>
    <p class="card-description">Dan Gorgone and guest Erik Erickson discuss the features and functionality of Google Analytics, including details and tips on demographics, acquisition, engagement, and conversion data analysis.</p>
    <div class="card-status">
      <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
      <span class="card-status-title">Viewed</span>
    </div>
</a>
  <ul class="card-tags tags">
    <li class="topic-business topic topic"><a data-filter-list-val="topic:business" href="/library/topic:business"><span>Business</span></a></li><li class="difficulty"><span>Beginner</span></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>


</li>


<li class="card workshop topic-python " data-location="library" data-activity="workshop/3042" id="Workshop-3042">

  <a class="card-box" href="/library/jupyter-notebooks/upcoming">
    <div class="card-progress">
      <svg class="workshop-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#workshop-icon"></use></svg>
      <span class="card-estimate add-topic-background-color"></span>
    </div>
    <strong class="card-type">Workshop</strong>
    <h3 class="card-title">Jupyter Notebooks</h3>
    <p class="card-description">The Jupyter project has an amazing tool for Python, Julia, R, and other languages. Learn how to install Jupyter Notebooks, use them, and install kernels for other languages.</p>
    <div class="card-status">
      <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
      <span class="card-status-title">Viewed</span>
    </div>
</a>
  <ul class="card-tags tags">
    <li class="topic-python topic topic"><a data-filter-list-val="topic:python" href="/library/topic:python"><span>Python</span></a></li><li class="upcoming-content"><span>July 2017</span></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>


</li>






<li class="card workshop topic-csharp " data-location="library" data-activity="workshop/2722" id="Workshop-2722">

  <a class="card-box" href="/library/net-core-cli-quick-start/upcoming">
    <div class="card-progress">
      <svg class="workshop-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#workshop-icon"></use></svg>
      <span class="card-estimate add-topic-background-color"></span>
    </div>
    <strong class="card-type">Workshop</strong>
    <h3 class="card-title">.NET Core CLI Quick Start</h3>
    <p class="card-description">In this quick start workshop, you'll learn how to use the .NET Core CLI to create a simple .NET Core console application.</p>
    <div class="card-status">
      <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
      <span class="card-status-title">Viewed</span>
    </div>
</a>
  <ul class="card-tags tags">
    <li class="pro-content"><a href="/account/enrollment"><span>Pro</span></a></li><li class="topic-csharp topic topic"><a data-filter-list-val="topic:csharp" href="/library/topic:csharp"><span>C#</span></a></li><li class="upcoming-content"><span>July 2017</span></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>


</li>


<li class="card course syllabus topic-javascript" data-location="library" data-activity="syllabus/3862" id="Syllabus-3862">

  <a class="card-box" href="/library/introduction-to-react-native/upcoming">
    <div class="card-progress">
      <svg class="course-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#course-icon"></use></svg>

      <ul class="card-stages">
      </ul>

      <span class="card-estimate"></span>
    </div>

    <strong class="card-type">Course</strong>
    <h3 class="card-title">Introduction to React Native</h3>
    <p class="card-description">
      React Native is a great option for creating performant iOS and Android applications that feel at home on their respective platforms, all while building on any previous web development experience. One of its greatest advantages is that it is written in Javascript and with that you can maximize code reuse between platforms. This course is going to go through the basics of React Native, Redux, third party API integration and the best ways to structure your React Native projects for success. In this course we will be building the ultimate superhero app. This app will let you build the superhero team of your dreams, well if you dream in Marvel that is. By the end of this course you should have the confidence to build upon the app that we started and take it to the next level.
    </p>


      <div class="card-status">
        <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
        <span class="card-status-title"></span>
      </div>
</a>
  <ul class="card-tags tags">
    <li class="topic-javascript topic topic"><a data-filter-list-val="topic:javascript" href="/library/topic:javascript"><span>JavaScript</span></a></li><li class="upcoming-content"><span>August 2017</span></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>
</li>



<li class="card course syllabus topic-color" data-location="library" data-activity="syllabus/3872" id="Syllabus-3872">

  <a class="card-box" href="/library/introduction-to-selenium/upcoming">
    <div class="card-progress">
      <svg class="course-icon card-icon" preserveAspectRatio="xMinYMin meet" viewBox="0 0 18 18">
        <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#course-icon"></use>
      </svg>

      <ul class="card-stages">
      </ul>

      <span class="card-estimate"></span>
    </div>

    <strong class="card-type">Course</strong>
    <h3 class="card-title">Introduction to Selenium </h3>
    <p class="card-description">
      As web applications grow in size it becomes difficult to reliably and thoroughly verify that the application behaves as intended.  Manually stepping through the system gets tedious and time consuming.  That's where automated testing tools become invaluable.
In this course we will learn to use Selenium Webdriver, one of the most popular utilities for automating interactions with web browsers, to build automated tests for the purpose of verifying and maintaining a quality application.
    </p>


      <div class="card-status">
        <svg class="complete-icon card-status-icon" preserveAspectRatio="xMinYMin meet" viewBox="140 0 140 120"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="/assets/icons-4546b065f01c8d6b7d308111c47e303eeef9892204014e435fbfd36801ea2c62.svg#complete-icon"></use></svg>
        <span class="card-status-title"></span>
      </div>
</a>
  <ul class="card-tags tags">
    <li class="topic- topic topic"><a data-filter-list-val="topic:qa" href="/library/topic:qa"><span>QA</span></a></li><li class="upcoming-content"><span>August 2017</span></li>
    <li class="truncated-tags"><span></span><ul></ul></li>
  </ul>
</li>



    </ul>

<section>

  <footer id="footer">

    <div class="treehouse-typelockup"></div>

    <p>
      ©2017 David Antonio Bolaños Lamprea AKA DABELOPER
    </p>

  </footer>

</section>

<script type="text/javascript" language="javascript">
    var user = <?php echo json_encode($_SESSION['user']); ?>;
</script>

<script type="text/javascript" src="./src/resources/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="./src/resources/main.js"></script>

  <body>
<html>